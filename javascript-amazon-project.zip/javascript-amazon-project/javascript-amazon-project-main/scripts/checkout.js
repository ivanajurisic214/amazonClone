import {renderOrderSummary} from './checkout/orderSummery.js';
import { renderPaymentSummary } from './checkout/paymentSummery.js';
//import '../data/cart-class.js';
import '../data/backend-practice.js';

renderOrderSummary();
renderPaymentSummary();